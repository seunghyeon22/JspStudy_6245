package web.service;

import java.util.ArrayList;

public interface FileService {
	public boolean uploadFile(ArrayList<String> fileList);
	
}
