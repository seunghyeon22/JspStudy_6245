package repository;

import java.util.ArrayList;

public interface FileDao {
	public int uploadFile(ArrayList<String> fileList);
}
